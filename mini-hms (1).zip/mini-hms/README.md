# 🏥 Mini Hospital Management System (HMS)

A full-stack hospital management web app built with **Django + PostgreSQL**, featuring doctor availability management, patient appointment booking, Google Calendar integration, and a serverless email notification service via AWS Lambda.

---

## 📋 Table of Contents

- [Features](#features)
- [Tech Stack](#tech-stack)
- [Project Structure](#project-structure)
- [Quick Start](#quick-start)
- [Serverless Email Service](#serverless-email-service)
- [Google Calendar Setup](#google-calendar-setup)
- [User Roles & Flows](#user-roles--flows)
- [API Reference](#api-reference)

---

## ✨ Features

- **Role-based auth** – Separate Doctor and Patient accounts with session-based login
- **Doctor availability** – Create single or bulk time slots by date & time
- **Patient booking** – Browse doctors, view available slots, book appointments
- **Race condition protection** – Database-level locking (`SELECT FOR UPDATE`) prevents double booking
- **Google Calendar** – Auto-creates events on both Doctor's and Patient's calendars on booking
- **Serverless emails** – AWS Lambda function (runnable locally with `serverless-offline`) sends:
  - `SIGNUP_WELCOME` on registration
  - `BOOKING_CONFIRMATION` on booking
- **Appointment management** – View, track, and cancel appointments

---

## 🛠 Tech Stack

| Layer | Technology |
|---|---|
| Backend | Django 4.2 |
| Database | PostgreSQL |
| ORM | Django ORM |
| Auth | Session-based (username + password) |
| Email Service | AWS Lambda + Serverless Framework |
| Local Email Testing | serverless-offline |
| Calendar | Google Calendar API (OAuth2) |
| Frontend | Django Templates + Bootstrap 5 |

---

## 📁 Project Structure

```
mini-hms/
├── hms_project/          # Django project config
│   ├── settings.py
│   └── urls.py
├── accounts/             # Auth, user model, dashboards, Google Calendar
│   ├── models.py         # Custom User (role: doctor/patient)
│   ├── views.py
│   ├── services.py       # send_email_notification() → Lambda
│   └── google_calendar.py
├── doctors/              # Availability slot management
│   ├── models.py         # DoctorProfile, AvailabilitySlot
│   └── views.py
├── appointments/         # Booking engine
│   ├── models.py         # Appointment
│   └── views.py          # Race-condition-safe booking
├── templates/            # HTML templates (Bootstrap 5)
├── static/css/           # Custom styles
├── serverless/           # Standalone Lambda email service
│   ├── handler.py        # Lambda function
│   ├── serverless.yml    # Serverless Framework config
│   └── package.json
├── requirements.txt
├── .env.example
└── manage.py
```

---

## 🚀 Quick Start

### 1. Clone the repository

```bash
git clone https://github.com/YOUR_USERNAME/mini-hospital-management-system.git
cd mini-hospital-management-system
```

### 2. Create virtual environment

```bash
python -m venv venv
source venv/bin/activate      # Windows: venv\Scripts\activate
```

### 3. Install Python dependencies

```bash
pip install -r requirements.txt
```

### 4. Configure environment variables

```bash
cp .env.example .env
# Edit .env with your values (DB password, SMTP credentials, etc.)
```

### 5. Set up PostgreSQL

```sql
-- In psql:
CREATE DATABASE hms_db;
CREATE USER postgres WITH PASSWORD 'yourpassword';
GRANT ALL PRIVILEGES ON DATABASE hms_db TO postgres;
```

### 6. Run migrations

```bash
python manage.py makemigrations
python manage.py migrate
```

### 7. Create a superuser (optional)

```bash
python manage.py createsuperuser
```

### 8. Run the Django server

```bash
python manage.py runserver
```

Visit: **http://localhost:8000**

---

## 📧 Serverless Email Service

The email service is a **separate mini-project** inside `/serverless/`.

### Setup

```bash
cd serverless
npm install
```

### Configure SMTP credentials

Create a `.env` file inside `serverless/`:

```env
SMTP_USER=your-email@gmail.com
SMTP_PASS=your-gmail-app-password
FROM_NAME=Mini HMS
```

> **Gmail tip:** Enable 2FA on your Google account, then generate an **App Password** at https://myaccount.google.com/apppasswords

### Run locally with serverless-offline

```bash
cd serverless
npx serverless offline
# Listening on http://localhost:3000
```

The Django app calls `http://localhost:3000/dev/send-email` automatically.

### Test the endpoint manually

```bash
curl -X POST http://localhost:3000/dev/send-email \
  -H "Content-Type: application/json" \
  -d '{
    "action": "SIGNUP_WELCOME",
    "recipient_email": "test@example.com",
    "recipient_name": "John Doe",
    "extra_data": {"role": "doctor"}
  }'
```

### Deploy to AWS (optional)

```bash
cd serverless
npx serverless deploy
# Update EMAIL_SERVICE_URL in your .env to the deployed Lambda URL
```

### Supported Actions

| Action | Trigger | Extra Data |
|---|---|---|
| `SIGNUP_WELCOME` | New user registration | `role` |
| `BOOKING_CONFIRMATION` | Appointment booked | `doctor_name`, `patient_name`, `date`, `start_time`, `end_time` |

---

## 📅 Google Calendar Setup

1. Go to [Google Cloud Console](https://console.cloud.google.com/)
2. Create a new project → Enable **Google Calendar API**
3. Go to **APIs & Services → Credentials → Create OAuth 2.0 Client ID**
4. Application type: **Web application**
5. Add Authorized redirect URI: `http://localhost:8000/accounts/google/callback/`
6. Copy **Client ID** and **Client Secret** into your `.env`
7. Users connect their calendar from their **Profile page** in the app

---

## 👥 User Roles & Flows

### Doctor Flow
```
Sign Up (role=doctor) → Welcome Email
→ Login → Doctor Dashboard
→ Update Profile (specialization, fee, bio)
→ Manage Slots → Add single / bulk slots
→ View bookings from patients
→ Connect Google Calendar (optional)
```

### Patient Flow
```
Sign Up (role=patient) → Welcome Email
→ Login → Patient Dashboard
→ Browse Doctors → View available slots
→ Book a slot → Confirmation Email + Calendar Event
→ View / Cancel appointments
```

---

## 🔒 Race Condition Protection

Appointments use `SELECT FOR UPDATE` with Django's `transaction.atomic()`:

```python
with transaction.atomic():
    slot = AvailabilitySlot.objects.select_for_update().get(id=slot_id)
    if slot.is_booked:
        # reject – already taken
    slot.is_booked = True
    slot.save()
    Appointment.objects.create(patient=request.user, slot=slot)
```

This ensures only one booking succeeds even under concurrent requests.

---

## 🌐 URL Reference

| URL | Description |
|---|---|
| `/accounts/signup/` | Sign up |
| `/accounts/login/` | Login |
| `/dashboard/` | Role-based dashboard redirect |
| `/dashboard/doctor/` | Doctor dashboard |
| `/dashboard/patient/` | Patient dashboard |
| `/doctors/` | Browse all doctors |
| `/doctors/<id>/` | Doctor detail + available slots |
| `/doctors/slots/` | Manage availability (doctor only) |
| `/appointments/book/<slot_id>/` | Book a slot (patient only) |
| `/appointments/my/` | My appointments |
| `/accounts/profile/` | User profile |
| `/accounts/google/connect/` | Connect Google Calendar |
| `/admin/` | Django admin |

---

## 📝 License

MIT License — free to use and modify.
