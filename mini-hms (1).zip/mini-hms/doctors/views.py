from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.utils import timezone
from datetime import datetime, timedelta
from .models import AvailabilitySlot, DoctorProfile
from .forms import AvailabilitySlotForm, DoctorProfileForm, BulkSlotForm
from accounts.models import User


def doctor_list(request):
    """Public list of all doctors with their profiles."""
    doctors = User.objects.filter(role='doctor').prefetch_related('doctor_profile')
    return render(request, 'doctors/doctor_list.html', {'doctors': doctors})


def doctor_detail(request, doctor_id):
    """View doctor's available slots."""
    doctor = get_object_or_404(User, id=doctor_id, role='doctor')
    today = timezone.now().date()
    slots = AvailabilitySlot.objects.filter(
        doctor=doctor,
        date__gte=today,
        is_booked=False
    ).order_by('date', 'start_time')
    profile = getattr(doctor, 'doctor_profile', None)
    return render(request, 'doctors/doctor_detail.html', {
        'doctor': doctor,
        'slots': slots,
        'profile': profile,
    })


@login_required
def manage_slots(request):
    if not request.user.is_doctor():
        messages.error(request, 'Access denied.')
        return redirect('dashboard')
    slots = AvailabilitySlot.objects.filter(doctor=request.user).order_by('date', 'start_time')
    form = AvailabilitySlotForm()
    return render(request, 'doctors/manage_slots.html', {'slots': slots, 'form': form})


@login_required
def add_slot(request):
    if not request.user.is_doctor():
        messages.error(request, 'Access denied.')
        return redirect('dashboard')
    if request.method == 'POST':
        form = AvailabilitySlotForm(request.POST)
        if form.is_valid():
            slot = form.save(commit=False)
            slot.doctor = request.user
            # Check for overlap
            overlap = AvailabilitySlot.objects.filter(
                doctor=request.user,
                date=slot.date,
                start_time__lt=slot.end_time,
                end_time__gt=slot.start_time,
            ).exists()
            if overlap:
                messages.error(request, 'This slot overlaps with an existing slot.')
            else:
                slot.save()
                messages.success(request, f'Slot added: {slot.date} {slot.start_time}–{slot.end_time}')
        else:
            for error in form.errors.values():
                messages.error(request, error)
    return redirect('manage_slots')


@login_required
def add_bulk_slots(request):
    """Generate multiple slots at once from a time range."""
    if not request.user.is_doctor():
        messages.error(request, 'Access denied.')
        return redirect('dashboard')
    if request.method == 'POST':
        form = BulkSlotForm(request.POST)
        if form.is_valid():
            date = form.cleaned_data['date']
            start = datetime.combine(date, form.cleaned_data['start_hour'])
            end = datetime.combine(date, form.cleaned_data['end_hour'])
            duration = timedelta(minutes=form.cleaned_data['slot_duration'])
            created = 0
            current = start
            while current + duration <= end:
                slot_start = current.time()
                slot_end = (current + duration).time()
                overlap = AvailabilitySlot.objects.filter(
                    doctor=request.user,
                    date=date,
                    start_time__lt=slot_end,
                    end_time__gt=slot_start,
                ).exists()
                if not overlap:
                    AvailabilitySlot.objects.get_or_create(
                        doctor=request.user,
                        date=date,
                        start_time=slot_start,
                        defaults={'end_time': slot_end}
                    )
                    created += 1
                current += duration
            messages.success(request, f'{created} slots created for {date}.')
        else:
            messages.error(request, 'Invalid form data.')
    return redirect('manage_slots')


@login_required
def delete_slot(request, slot_id):
    if not request.user.is_doctor():
        messages.error(request, 'Access denied.')
        return redirect('dashboard')
    slot = get_object_or_404(AvailabilitySlot, id=slot_id, doctor=request.user)
    if slot.is_booked:
        messages.error(request, 'Cannot delete a booked slot.')
    else:
        slot.delete()
        messages.success(request, 'Slot deleted.')
    return redirect('manage_slots')


@login_required
def update_profile(request):
    if not request.user.is_doctor():
        messages.error(request, 'Access denied.')
        return redirect('dashboard')
    profile, _ = DoctorProfile.objects.get_or_create(doctor=request.user)
    if request.method == 'POST':
        form = DoctorProfileForm(request.POST, instance=profile)
        if form.is_valid():
            form.save()
            messages.success(request, 'Profile updated.')
            return redirect('doctor_dashboard')
    else:
        form = DoctorProfileForm(instance=profile)
    return render(request, 'doctors/update_profile.html', {'form': form})
