from django.urls import path
from . import views

urlpatterns = [
    path('', views.doctor_list, name='doctor_list'),
    path('<int:doctor_id>/', views.doctor_detail, name='doctor_detail'),
    path('slots/', views.manage_slots, name='manage_slots'),
    path('slots/add/', views.add_slot, name='add_slot'),
    path('slots/bulk/', views.add_bulk_slots, name='add_bulk_slots'),
    path('slots/<int:slot_id>/delete/', views.delete_slot, name='delete_slot'),
    path('profile/update/', views.update_profile, name='update_doctor_profile'),
]
