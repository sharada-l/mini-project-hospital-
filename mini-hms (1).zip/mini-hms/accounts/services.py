import requests
import logging
from django.conf import settings

logger = logging.getLogger(__name__)


def send_email_notification(action, recipient_email, recipient_name, extra_data=None):
    """
    Calls the serverless email Lambda function via HTTP.
    action: SIGNUP_WELCOME | BOOKING_CONFIRMATION
    """
    payload = {
        'action': action,
        'recipient_email': recipient_email,
        'recipient_name': recipient_name,
        'extra_data': extra_data or {},
    }
    try:
        response = requests.post(
            settings.EMAIL_SERVICE_URL,
            json=payload,
            timeout=10
        )
        response.raise_for_status()
        logger.info(f"Email sent: {action} to {recipient_email}")
        return response.json()
    except requests.exceptions.ConnectionError:
        logger.warning(f"Email service unreachable. Skipping {action} for {recipient_email}")
    except requests.exceptions.Timeout:
        logger.warning(f"Email service timed out for {action}")
    except Exception as e:
        logger.error(f"Email service error: {e}")
    return None
