import requests
import json
from django.conf import settings


GOOGLE_AUTH_URL = "https://accounts.google.com/o/oauth2/v2/auth"
GOOGLE_TOKEN_URL = "https://oauth2.googleapis.com/token"
GOOGLE_CALENDAR_API = "https://www.googleapis.com/calendar/v3"
SCOPES = "https://www.googleapis.com/auth/calendar"


def get_auth_url():
    params = {
        "client_id": settings.GOOGLE_CLIENT_ID,
        "redirect_uri": settings.GOOGLE_REDIRECT_URI,
        "response_type": "code",
        "scope": SCOPES,
        "access_type": "offline",
        "prompt": "consent",
    }
    query = "&".join(f"{k}={v}" for k, v in params.items())
    return f"{GOOGLE_AUTH_URL}?{query}"


def exchange_code_for_token(code):
    data = {
        "code": code,
        "client_id": settings.GOOGLE_CLIENT_ID,
        "client_secret": settings.GOOGLE_CLIENT_SECRET,
        "redirect_uri": settings.GOOGLE_REDIRECT_URI,
        "grant_type": "authorization_code",
    }
    response = requests.post(GOOGLE_TOKEN_URL, data=data)
    response.raise_for_status()
    return response.json()


def refresh_access_token(refresh_token):
    data = {
        "refresh_token": refresh_token,
        "client_id": settings.GOOGLE_CLIENT_ID,
        "client_secret": settings.GOOGLE_CLIENT_SECRET,
        "grant_type": "refresh_token",
    }
    response = requests.post(GOOGLE_TOKEN_URL, data=data)
    response.raise_for_status()
    return response.json().get("access_token")


def create_calendar_event(user, title, start_datetime, end_datetime, description=""):
    """Create a Google Calendar event for a user."""
    if not user.google_calendar_connected:
        return None

    access_token = user.google_calendar_token

    # Try to refresh if needed
    if user.google_calendar_refresh_token:
        try:
            access_token = refresh_access_token(user.google_calendar_refresh_token)
            user.google_calendar_token = access_token
            user.save(update_fields=['google_calendar_token'])
        except Exception:
            pass

    headers = {
        "Authorization": f"Bearer {access_token}",
        "Content-Type": "application/json",
    }
    event = {
        "summary": title,
        "description": description,
        "start": {"dateTime": start_datetime.isoformat(), "timeZone": "UTC"},
        "end": {"dateTime": end_datetime.isoformat(), "timeZone": "UTC"},
    }
    response = requests.post(
        f"{GOOGLE_CALENDAR_API}/calendars/primary/events",
        headers=headers,
        json=event,
    )
    if response.status_code == 200 or response.status_code == 201:
        return response.json().get("id")
    return None


def create_appointment_events(appointment):
    """Create calendar events for both doctor and patient."""
    from datetime import datetime, date, time as dtime

    slot = appointment.slot
    start_dt = datetime.combine(slot.date, slot.start_time)
    end_dt = datetime.combine(slot.date, slot.end_time)

    doctor = slot.doctor
    patient = appointment.patient

    doctor_title = f"Appointment with {patient.get_full_name() or patient.username}"
    patient_title = f"Appointment with Dr. {doctor.get_full_name() or doctor.username}"
    description = f"Hospital appointment booked via Mini HMS."

    doctor_event_id = create_calendar_event(doctor, doctor_title, start_dt, end_dt, description)
    patient_event_id = create_calendar_event(patient, patient_title, start_dt, end_dt, description)

    return doctor_event_id, patient_event_id
