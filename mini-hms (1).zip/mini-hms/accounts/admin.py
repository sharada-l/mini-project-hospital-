from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import User


@admin.register(User)
class CustomUserAdmin(UserAdmin):
    list_display = ['username', 'email', 'first_name', 'last_name', 'role', 'google_calendar_connected']
    list_filter = ['role', 'google_calendar_connected']
    fieldsets = UserAdmin.fieldsets + (
        ('HMS Info', {'fields': ('role', 'phone', 'google_calendar_connected')}),
    )
