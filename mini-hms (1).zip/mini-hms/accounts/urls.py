from django.urls import path
from . import views

urlpatterns = [
    path('signup/', views.signup_view, name='signup'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('profile/', views.profile_view, name='profile'),
    path('google/connect/', views.google_calendar_connect, name='google_connect'),
    path('google/callback/', views.google_calendar_callback, name='google_callback'),
]
