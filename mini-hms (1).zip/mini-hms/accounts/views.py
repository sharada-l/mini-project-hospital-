from django.shortcuts import render, redirect
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.conf import settings
from .forms import SignupForm, LoginForm, ProfileUpdateForm
from .models import User
from .services import send_email_notification
import json


def signup_view(request):
    if request.user.is_authenticated:
        return redirect('dashboard')
    if request.method == 'POST':
        form = SignupForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            # Send welcome email via serverless function
            send_email_notification(
                action='SIGNUP_WELCOME',
                recipient_email=user.email,
                recipient_name=user.get_full_name() or user.username,
                extra_data={'role': user.role}
            )
            messages.success(request, f'Welcome, {user.first_name}! Your account has been created.')
            return redirect('dashboard')
        else:
            messages.error(request, 'Please fix the errors below.')
    else:
        form = SignupForm()
    return render(request, 'accounts/signup.html', {'form': form})


def login_view(request):
    if request.user.is_authenticated:
        return redirect('dashboard')
    if request.method == 'POST':
        form = LoginForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            messages.success(request, f'Welcome back, {user.first_name or user.username}!')
            return redirect('dashboard')
        else:
            messages.error(request, 'Invalid username or password.')
    else:
        form = LoginForm()
    return render(request, 'accounts/login.html', {'form': form})


@login_required
def logout_view(request):
    logout(request)
    messages.info(request, 'You have been logged out.')
    return redirect('login')


@login_required
def dashboard_view(request):
    if request.user.is_doctor():
        return redirect('doctor_dashboard')
    return redirect('patient_dashboard')


@login_required
def doctor_dashboard(request):
    if not request.user.is_doctor():
        messages.error(request, 'Access denied.')
        return redirect('dashboard')
    from doctors.models import AvailabilitySlot
    from appointments.models import Appointment
    slots = AvailabilitySlot.objects.filter(doctor=request.user).order_by('date', 'start_time')
    appointments = Appointment.objects.filter(slot__doctor=request.user).select_related('patient', 'slot').order_by('-slot__date')
    context = {
        'slots': slots,
        'appointments': appointments,
        'total_slots': slots.count(),
        'booked_slots': slots.filter(is_booked=True).count(),
        'available_slots': slots.filter(is_booked=False).count(),
    }
    return render(request, 'accounts/doctor_dashboard.html', context)


@login_required
def patient_dashboard(request):
    if not request.user.is_patient():
        messages.error(request, 'Access denied.')
        return redirect('dashboard')
    from appointments.models import Appointment
    appointments = Appointment.objects.filter(patient=request.user).select_related('slot__doctor').order_by('-slot__date')
    context = {
        'appointments': appointments,
        'upcoming': appointments.filter(status='confirmed').count(),
    }
    return render(request, 'accounts/patient_dashboard.html', context)


@login_required
def profile_view(request):
    if request.method == 'POST':
        form = ProfileUpdateForm(request.POST, instance=request.user)
        if form.is_valid():
            form.save()
            messages.success(request, 'Profile updated successfully.')
            return redirect('profile')
    else:
        form = ProfileUpdateForm(instance=request.user)
    return render(request, 'accounts/profile.html', {'form': form})


@login_required
def google_calendar_connect(request):
    from .google_calendar import get_auth_url
    auth_url = get_auth_url()
    return redirect(auth_url)


@login_required
def google_calendar_callback(request):
    from .google_calendar import exchange_code_for_token
    code = request.GET.get('code')
    if not code:
        messages.error(request, 'Google Calendar authorization failed.')
        return redirect('profile')
    try:
        token_data = exchange_code_for_token(code)
        request.user.google_calendar_token = token_data.get('access_token')
        request.user.google_calendar_refresh_token = token_data.get('refresh_token', '')
        request.user.google_calendar_connected = True
        request.user.save()
        messages.success(request, 'Google Calendar connected successfully!')
    except Exception as e:
        messages.error(request, f'Failed to connect Google Calendar: {str(e)}')
    return redirect('profile')
