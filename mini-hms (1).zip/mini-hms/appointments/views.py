from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db import transaction
from django.utils import timezone
from doctors.models import AvailabilitySlot, DoctorProfile
from accounts.models import User
from .models import Appointment
from accounts.services import send_email_notification
from accounts.google_calendar import create_appointment_events


@login_required
def book_slot(request, slot_id):
    if not request.user.is_patient():
        messages.error(request, 'Only patients can book appointments.')
        return redirect('dashboard')

    # Use select_for_update to prevent race conditions
    with transaction.atomic():
        slot = get_object_or_404(
            AvailabilitySlot.objects.select_for_update(),
            id=slot_id
        )

        if slot.is_booked:
            messages.error(request, 'Sorry, this slot was just booked by someone else.')
            return redirect('doctor_detail', doctor_id=slot.doctor.id)

        if not slot.is_available():
            messages.error(request, 'This slot is no longer available.')
            return redirect('doctor_detail', doctor_id=slot.doctor.id)

        # Check patient doesn't already have an appointment with this doctor on this date
        existing = Appointment.objects.filter(
            patient=request.user,
            slot__doctor=slot.doctor,
            slot__date=slot.date,
            status=Appointment.STATUS_CONFIRMED
        ).exists()
        if existing:
            messages.error(request, 'You already have an appointment with this doctor on this date.')
            return redirect('doctor_detail', doctor_id=slot.doctor.id)

        notes = request.POST.get('notes', '')

        # Create appointment and mark slot as booked
        appointment = Appointment.objects.create(
            patient=request.user,
            slot=slot,
            notes=notes,
            status=Appointment.STATUS_CONFIRMED
        )
        slot.is_booked = True
        slot.save(update_fields=['is_booked'])

    # Google Calendar events (outside transaction - non-critical)
    try:
        doctor_event_id, patient_event_id = create_appointment_events(appointment)
        if doctor_event_id:
            appointment.google_event_id_doctor = doctor_event_id
        if patient_event_id:
            appointment.google_event_id_patient = patient_event_id
        appointment.save(update_fields=['google_event_id_doctor', 'google_event_id_patient'])
    except Exception:
        pass  # Calendar is optional, don't fail booking

    # Send confirmation emails via serverless Lambda
    doctor = slot.doctor
    patient = request.user
    extra = {
        'doctor_name': f"Dr. {doctor.get_full_name() or doctor.username}",
        'patient_name': patient.get_full_name() or patient.username,
        'date': str(slot.date),
        'start_time': str(slot.start_time),
        'end_time': str(slot.end_time),
    }
    send_email_notification('BOOKING_CONFIRMATION', patient.email, patient.get_full_name(), extra)
    send_email_notification('BOOKING_CONFIRMATION', doctor.email, f"Dr. {doctor.get_full_name()}", extra)

    messages.success(request, f'Appointment booked with Dr. {doctor.get_full_name()} on {slot.date} at {slot.start_time}!')
    return redirect('appointment_detail', appointment_id=appointment.id)


@login_required
def appointment_detail(request, appointment_id):
    if request.user.is_patient():
        appointment = get_object_or_404(Appointment, id=appointment_id, patient=request.user)
    else:
        appointment = get_object_or_404(Appointment, id=appointment_id, slot__doctor=request.user)
    return render(request, 'appointments/appointment_detail.html', {'appointment': appointment})


@login_required
def cancel_appointment(request, appointment_id):
    if request.user.is_patient():
        appointment = get_object_or_404(Appointment, id=appointment_id, patient=request.user)
    else:
        appointment = get_object_or_404(Appointment, id=appointment_id, slot__doctor=request.user)

    if appointment.status != Appointment.STATUS_CONFIRMED:
        messages.error(request, 'This appointment cannot be cancelled.')
        return redirect('appointment_detail', appointment_id=appointment.id)

    if request.method == 'POST':
        with transaction.atomic():
            appointment.status = Appointment.STATUS_CANCELLED
            appointment.save(update_fields=['status'])
            slot = appointment.slot
            slot.is_booked = False
            slot.save(update_fields=['is_booked'])
        messages.success(request, 'Appointment cancelled successfully.')
        return redirect('patient_dashboard' if request.user.is_patient() else 'doctor_dashboard')

    return render(request, 'appointments/cancel_confirm.html', {'appointment': appointment})


@login_required
def my_appointments(request):
    if request.user.is_patient():
        appointments = Appointment.objects.filter(
            patient=request.user
        ).select_related('slot__doctor').order_by('-slot__date')
    else:
        appointments = Appointment.objects.filter(
            slot__doctor=request.user
        ).select_related('patient', 'slot').order_by('-slot__date')
    return render(request, 'appointments/my_appointments.html', {'appointments': appointments})
