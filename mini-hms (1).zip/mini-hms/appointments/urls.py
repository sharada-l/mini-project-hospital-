from django.urls import path
from . import views

urlpatterns = [
    path('book/<int:slot_id>/', views.book_slot, name='book_slot'),
    path('<int:appointment_id>/', views.appointment_detail, name='appointment_detail'),
    path('<int:appointment_id>/cancel/', views.cancel_appointment, name='cancel_appointment'),
    path('my/', views.my_appointments, name='my_appointments'),
]
