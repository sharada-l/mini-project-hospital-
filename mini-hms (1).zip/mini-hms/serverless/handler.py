"""
Mini HMS – Serverless Email Service
AWS Lambda function to send transactional emails.
Run locally with: serverless offline
"""

import json
import os
import smtplib
import logging
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# ── SMTP config from env vars ──────────────────────────────────────────────
SMTP_HOST = os.environ.get("SMTP_HOST", "smtp.gmail.com")
SMTP_PORT = int(os.environ.get("SMTP_PORT", "587"))
SMTP_USER = os.environ.get("SMTP_USER", "")
SMTP_PASS = os.environ.get("SMTP_PASS", "")
FROM_NAME = os.environ.get("FROM_NAME", "Mini HMS")
FROM_EMAIL = SMTP_USER


# ── Email templates ────────────────────────────────────────────────────────

def render_signup_welcome(name, role):
    subject = f"Welcome to Mini HMS, {name}!"
    html = f"""
    <div style="font-family:Arial,sans-serif;max-width:560px;margin:auto;background:#fff;border-radius:12px;overflow:hidden;box-shadow:0 2px 12px rgba(0,0,0,0.08);">
      <div style="background:#0d6efd;padding:32px 40px;text-align:center;">
        <h1 style="color:#fff;margin:0;font-size:24px;">🏥 Mini HMS</h1>
        <p style="color:#cce0ff;margin:8px 0 0;">Hospital Management System</p>
      </div>
      <div style="padding:36px 40px;">
        <h2 style="color:#1a1a2e;margin-top:0;">Welcome, {name}! 👋</h2>
        <p style="color:#555;line-height:1.6;">
          Your account has been successfully created as a <strong>{role.title()}</strong>.
        </p>
        {'<p style="color:#555;line-height:1.6;">You can now <strong>set your availability slots</strong> and manage patient appointments from your dashboard.</p>' if role == 'doctor' else '<p style="color:#555;line-height:1.6;">You can now <strong>browse doctors</strong> and book appointments directly from your dashboard.</p>'}
        <div style="text-align:center;margin:28px 0;">
          <a href="http://localhost:8000/dashboard/" style="background:#0d6efd;color:#fff;padding:12px 28px;border-radius:8px;text-decoration:none;font-weight:600;display:inline-block;">
            Go to Dashboard →
          </a>
        </div>
        <p style="color:#999;font-size:13px;">If you didn't create this account, please ignore this email.</p>
      </div>
      <div style="background:#f8f9fa;padding:16px 40px;text-align:center;">
        <p style="color:#aaa;font-size:12px;margin:0;">© 2025 Mini HMS · All rights reserved</p>
      </div>
    </div>
    """
    return subject, html


def render_booking_confirmation(recipient_name, doctor_name, patient_name, date, start_time, end_time):
    subject = f"Appointment Confirmed – {date} at {start_time}"
    html = f"""
    <div style="font-family:Arial,sans-serif;max-width:560px;margin:auto;background:#fff;border-radius:12px;overflow:hidden;box-shadow:0 2px 12px rgba(0,0,0,0.08);">
      <div style="background:#198754;padding:32px 40px;text-align:center;">
        <h1 style="color:#fff;margin:0;font-size:24px;">✅ Appointment Confirmed</h1>
        <p style="color:#c3e6cb;margin:8px 0 0;">Mini HMS</p>
      </div>
      <div style="padding:36px 40px;">
        <h2 style="color:#1a1a2e;margin-top:0;">Hello, {recipient_name}!</h2>
        <p style="color:#555;line-height:1.6;">Your appointment has been confirmed. Here are the details:</p>

        <div style="background:#f8f9fa;border-radius:10px;padding:20px 24px;margin:24px 0;">
          <table style="width:100%;border-collapse:collapse;">
            <tr>
              <td style="color:#888;font-size:13px;padding:6px 0;">Doctor</td>
              <td style="font-weight:600;color:#1a1a2e;text-align:right;">{doctor_name}</td>
            </tr>
            <tr>
              <td style="color:#888;font-size:13px;padding:6px 0;">Patient</td>
              <td style="font-weight:600;color:#1a1a2e;text-align:right;">{patient_name}</td>
            </tr>
            <tr>
              <td style="color:#888;font-size:13px;padding:6px 0;">Date</td>
              <td style="font-weight:600;color:#0d6efd;text-align:right;">📅 {date}</td>
            </tr>
            <tr>
              <td style="color:#888;font-size:13px;padding:6px 0;">Time</td>
              <td style="font-weight:600;color:#0d6efd;text-align:right;">🕐 {start_time} – {end_time}</td>
            </tr>
          </table>
        </div>

        <div style="text-align:center;margin:24px 0;">
          <a href="http://localhost:8000/appointments/my/" style="background:#198754;color:#fff;padding:12px 28px;border-radius:8px;text-decoration:none;font-weight:600;display:inline-block;">
            View Appointment →
          </a>
        </div>
        <p style="color:#999;font-size:13px;">To cancel, visit your dashboard before the scheduled time.</p>
      </div>
      <div style="background:#f8f9fa;padding:16px 40px;text-align:center;">
        <p style="color:#aaa;font-size:12px;margin:0;">© 2025 Mini HMS · All rights reserved</p>
      </div>
    </div>
    """
    return subject, html


# ── SMTP send ──────────────────────────────────────────────────────────────

def send_email(to_email, subject, html_body):
    if not SMTP_USER or not SMTP_PASS:
        logger.warning("SMTP credentials not set. Skipping email send.")
        return False

    msg = MIMEMultipart("alternative")
    msg["Subject"] = subject
    msg["From"] = f"{FROM_NAME} <{FROM_EMAIL}>"
    msg["To"] = to_email
    msg.attach(MIMEText(html_body, "html"))

    try:
        with smtplib.SMTP(SMTP_HOST, SMTP_PORT) as server:
            server.ehlo()
            server.starttls()
            server.login(SMTP_USER, SMTP_PASS)
            server.sendmail(FROM_EMAIL, to_email, msg.as_string())
        logger.info(f"Email sent to {to_email}: {subject}")
        return True
    except Exception as e:
        logger.error(f"Failed to send email to {to_email}: {e}")
        return False


# ── Lambda handler ─────────────────────────────────────────────────────────

def send_email_handler(event, context):
    """
    Main Lambda handler. Called via HTTP POST from the Django app.

    Expected body:
    {
        "action": "SIGNUP_WELCOME" | "BOOKING_CONFIRMATION",
        "recipient_email": "user@example.com",
        "recipient_name": "John Doe",
        "extra_data": { ... }
    }
    """
    headers = {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
    }

    try:
        # Parse body (API Gateway wraps it as a string)
        if isinstance(event.get("body"), str):
            body = json.loads(event["body"])
        elif isinstance(event.get("body"), dict):
            body = event["body"]
        else:
            body = event  # direct invocation (e.g. from tests)

        action = body.get("action", "")
        recipient_email = body.get("recipient_email", "")
        recipient_name = body.get("recipient_name", "User")
        extra = body.get("extra_data", {})

        if not recipient_email:
            return {
                "statusCode": 400,
                "headers": headers,
                "body": json.dumps({"error": "recipient_email is required"}),
            }

        # ── Route by action ────────────────────────────────────────────
        if action == "SIGNUP_WELCOME":
            role = extra.get("role", "patient")
            subject, html = render_signup_welcome(recipient_name, role)

        elif action == "BOOKING_CONFIRMATION":
            subject, html = render_booking_confirmation(
                recipient_name=recipient_name,
                doctor_name=extra.get("doctor_name", "Doctor"),
                patient_name=extra.get("patient_name", "Patient"),
                date=extra.get("date", ""),
                start_time=extra.get("start_time", ""),
                end_time=extra.get("end_time", ""),
            )

        else:
            return {
                "statusCode": 400,
                "headers": headers,
                "body": json.dumps({"error": f"Unknown action: {action}"}),
            }

        success = send_email(recipient_email, subject, html)

        return {
            "statusCode": 200 if success else 500,
            "headers": headers,
            "body": json.dumps({
                "success": success,
                "action": action,
                "recipient": recipient_email,
                "message": "Email sent successfully" if success else "Email failed – check SMTP config",
            }),
        }

    except json.JSONDecodeError:
        return {
            "statusCode": 400,
            "headers": headers,
            "body": json.dumps({"error": "Invalid JSON body"}),
        }
    except Exception as e:
        logger.error(f"Unexpected error: {e}")
        return {
            "statusCode": 500,
            "headers": headers,
            "body": json.dumps({"error": str(e)}),
        }
